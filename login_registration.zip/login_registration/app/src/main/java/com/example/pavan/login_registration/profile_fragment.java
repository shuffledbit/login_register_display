package com.example.pavan.login_registration;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import com.example.pavan.login_registration.library.WaveHelper;
import com.example.pavan.login_registration.library.WaveView;

public class profile_fragment extends Fragment {
    int onStartCount = 0;
private TextView madd;

int  size=21;
   // final static String urlAddress="http://192.168.43.179/spacecraft_select_images.php";
    public profile_fragment() {

    }
    //View view;
  private WaveHelper mWaveHelper;
    private int lastPosition=1;
    private int mBorderColor = Color.parseColor("#44FFFFFF");
    private int mBorderWidth = 10;
    TextView text1,name,email,phone;
    View view;
    private static final String FORMAT = "%02d:%02d:%02d";
    private static int a=1;

    private List<Data> data;
    Context context;
    private ImageView backButtonImage;
    private Animation rotation;
    int seconds , minutes;
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.activity_new_water, container, false);



name=(TextView) view.findViewById(R.id.name);
        email=(TextView) view.findViewById(R.id.email);
        phone=(TextView) view.findViewById(R.id.phone);
        name.setText(MainActivity.name);
        email.setText(MainActivity.email);
       // phone.setText(MainActivity.password);

       GridLayoutManager gridLayout = new GridLayoutManager(getActivity(), 1);

        final WaveView waveView = (WaveView) view.findViewById(R.id.wave);
        mWaveHelper = new WaveHelper(waveView);
        waveView.setShapeType(WaveView.ShapeType.CIRCLE);
        mBorderWidth = 8;

        waveView.setWaveColor(Color.parseColor("#77cdfa"),
                Color.parseColor("#40b6ff"));
        mBorderColor = Color.parseColor("#8c8b8b");


        return view;
    }
   @Override
    public void onPause() {
        super.onPause();
        mWaveHelper.cancel();
    }
    @Override
    public void onResume() {
        super.onResume();
        mWaveHelper.start();
    }
}
