package com.example.pavan.login_registration;

public class Data {
    public int imageId;
    public String txt;

    Data(int imageId, String text) {
        this.imageId = imageId;
        //this.txt=text;
    }
}