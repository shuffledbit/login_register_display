package com.example.pavan.login_registration;

/**
 * Created by USER on 28-08-2017.
 */

public class person_details {

    int id;
    String password;
    String name;
    String email;
    String user_type;
    String address;
    //String phone;

    public person_details() {


    }

 /*   public Student_details(String name, String usn, String course, int semester, String section) {
       this.name=name;
        this.usn=usn;
        this.course=course;
        this.semester=semester;
        this.section=section;
    }*/

    public person_details(int id, String name, String email, String password, String user_type, String address) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.user_type = user_type;
        this.address = address;

    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getId() {
        return id;
    }



    public void setId(int id) {
        this.id = id;

    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
