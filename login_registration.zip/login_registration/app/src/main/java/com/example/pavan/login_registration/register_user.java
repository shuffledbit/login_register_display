package com.example.pavan.login_registration;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class register_user extends AppCompatActivity implements View.OnClickListener
{
    private EditText mbranch,mphone,maddress;
    private Spinner Appspinner;
    String degreeval="";
    String yearval="";
    String sectionval="";
    String  degreevals;
    private String[] degree = new String[]
            {
                    "STUDENT",
                    "EMPLOYEE"
            };
    private TextView alRegistered;
    private EditText edUsername, edPassword, edEmail;
    private Button register;
    private ProgressDialog progressDialog;
    private static final String url=Config.SERVER_IP+"/userRegister.php";
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
        alRegistered = (TextView) findViewById(R.id.alRegistered);
        edUsername = (EditText) findViewById(R.id.username);
        edPassword = (EditText) findViewById(R.id.password);
        edEmail = (EditText) findViewById(R.id.email);
        mphone  = (EditText) findViewById(R.id.phone);
        register = (Button) findViewById(R.id.btnRegister);
        mbranch=(EditText) findViewById(R.id.branchnew);
        maddress=(EditText) findViewById(R.id.address);
        Appspinner=(Spinner) findViewById(R.id.spinnerfst);
        progressDialog=new ProgressDialog(this);
        register.setOnClickListener(this);
        alRegistered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentss = new Intent(register_user.this, MainActivity.class);
                startActivity(intentss);
            }
        });


        final List<String> plantsList = new ArrayList<>(Arrays.asList(degree));

        // Initializing an ArrayAdapter
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                this,R.layout.support_simple_spinner_dropdown_item,plantsList){
            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                View v = Appspinner.getSelectedView();
                ((TextView)v).setTextColor(Color.parseColor("#f6f7fa"));
                if(position%2 == 1) {


                }
                else {

                }
                return view;
            }
        };
        spinnerArrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        Appspinner.setAdapter(spinnerArrayAdapter);

        Appspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                degreeval = (String) parent.getItemAtPosition(position);
                // Notify the selected item text
                degreevals = Appspinner.getSelectedItem().toString();
                mbranch.setText(degreevals);
                // loadData();
                //   Apptextspinner.setText(selectedItemText);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void Register(){
        StringRequest stringRequest;
        final String username = edUsername.getText().toString().trim();
        final String password = edPassword.getText().toString().trim();
        final String email = edEmail.getText().toString().trim();
        final String user_type = mbranch.getText().toString().trim();
        final String phone = mphone.getText().toString().trim();
        final String address = maddress.getText().toString().trim();
        progressDialog.setMessage("Requesting");
        progressDialog.show();
        stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(s);

                            Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }


                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        progressDialog.hide();
                        Toast.makeText(getApplicationContext(), volleyError.getMessage(), Toast.LENGTH_LONG).show();
                    }

                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                params.put("email", email);
                params.put("user_type", user_type);
                params.put("phone", phone);
                params.put("address", address);
                return params;
            }


        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);

        requestQueue.add(stringRequest);


    }



    @Override
    public void onClick(View view) {
        if(view==register){
            Register();
           /* edUsername.setText("");
            edPassword.setText("");
            edEmail.setText("");
            mbranch.setText("");
            mphone.setText("");
            maddress.setText("");*/
        }
    }
    public void onClickText(View  v){
        if(v==alRegistered) {
            Intent intent = new Intent(register_user.this, MainActivity.class);
            startActivity(intent);
        }
    }

}





