package com.example.pavan.login_registration;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public  static  String name;
    public  static String email;
    public  static String phone;
    public  static String password;
    public  static String user_type;
    public  static String address;
    public  static int id;
    String ss=null;
    private TextView newUser;
    private EditText edUsers,edPasswords;





    private EditText mbranch;
    private ProgressDialog progressDialog;
    private Button login;
    private static final String url=Config.SERVER_IP+"/login.php";

    public static ArrayList<person_details> detaillist = new ArrayList<person_details>();


    public static person_details table;

    private Spinner Appspinner;

    String degreeval="";

    String  degreevals;
    private String[] degree = new String[]
            {
                    "STUDENT",
                    "EMPLOYEE"
            };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressDialog=new ProgressDialog(this);
        newUser = (TextView) findViewById(R.id.newUser);
        edUsers = (EditText) findViewById(R.id.edUser);
        edPasswords = (EditText) findViewById(R.id.edPassword);
        mbranch=(EditText) findViewById(R.id.branchnew);

        Appspinner=(Spinner) findViewById(R.id.spinnerfst);
        login = (Button) findViewById(R.id.login);
     /* final   ProgressDialog progressDialog = null;
        progressDialog.setMessage("Requesting");
        progressDialog.show();*/
        //login.setOnClickListener(this);
        final List<String> plantsList = new ArrayList<>(Arrays.asList(degree));

        // Initializing an ArrayAdapter
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                this,R.layout.support_simple_spinner_dropdown_item,plantsList){
            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                View v = Appspinner.getSelectedView();
                ((TextView)v).setTextColor(Color.parseColor("#f6f7fa"));
                if(position%2 == 1) {


                }
                else {

                }
                return view;
            }
        };
        spinnerArrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        Appspinner.setAdapter(spinnerArrayAdapter);

        Appspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                degreeval = (String) parent.getItemAtPosition(position);
                // Notify the selected item text
                degreevals = Appspinner.getSelectedItem().toString();
                mbranch.setText(degreevals);
                // loadData();
                //   Apptextspinner.setText(selectedItemText);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intents=new Intent(MainActivity.this,register_user.class);
                startActivity(intents);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username = edUsers.getText().toString().trim();
                String password = edPasswords.getText().toString().trim();
                String user_type = mbranch.getText().toString().trim();
                if(username.isEmpty())
                {
                    edUsers.setError("please enter name");
                }
                else if(password.isEmpty()) {
                    edPasswords.setError("please enter password");
                }
                else if(user_type.isEmpty()) {

                    edPasswords.setError("please enter password");

                }
                else
                {
                    registerUser1();
                }
            }
        });
    }


    private void registerUser1()
    {
        final String a=String.valueOf(mbranch.getText().toString());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        detaillist.clear();
                        JSONObject jsonResponse;
                        try {
                            jsonResponse = new JSONObject(response);
                            JSONArray jsonArray = jsonResponse.getJSONArray("products");
                            for(int t=0;t<jsonArray.length();t++)
                            {
                                JSONObject object = jsonArray.getJSONObject(t);
                                person_details table = new person_details();
                                table.setId(object.getInt("id"));
                                table.setEmail(object.getString("email"));
                                table.setPassword(object.getString("password"));
                                table.setName(object.getString("name"));
                                table.setUser_type(object.getString("user_type"));
                                table.setAddress(object.getString("address"));

                                detaillist.add(table);



                                Intent ii = new Intent(MainActivity.this,CustomViewIconTextTabsActivity.class);
                                startActivity(ii);




                            }

                        } catch (JSONException e) {
                            Toast.makeText(MainActivity.this,"invlaid credentials",Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                        for (int i=0;i<detaillist.size();i++){
                            name = MainActivity.detaillist.get(i).getName();
                            email=   MainActivity.detaillist.get(i).getEmail();
                            password=MainActivity.detaillist.get(i).getPassword();
                            user_type=MainActivity.detaillist.get(i).getUser_type();
                            address=MainActivity.detaillist.get(i).getAddress();

                            id=MainActivity.detaillist.get(i).getId();

                        }
                    }
                },
                new Response.ErrorListener() {


                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //  loading.dismiss();
                        Toast.makeText(MainActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("name", String.valueOf(edUsers.getText().toString()));
                params.put("password", String.valueOf(edPasswords.getText().toString()));
                params.put("user_type", String.valueOf(mbranch.getText().toString()));
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }




    public void Click(View view) {

        Intent intent=new Intent(MainActivity.this,MainActivity.class);
        startActivity(intent);

    }
}
