package com.example.pavan.login_registration;

/**
 * Created by pavan on 16/03/2018.
 */
public class Config {

    public static final String SERVER_IP = "http://192.168.43.161";

}