<?php

  define("db_name","demo");
define("mysql_username","root");
define("mysql_password","");
define("server_name","localhost");

$con=mysqli_connect(server_name,mysql_username,mysql_password,db_name);
   if(mysqli_connect_errno())
   {
	   echo "could not connect to the database".mysqli_connect_error();
	  die(); 
   }

   
   function createUser($username,$password,$email,$user_type,$phone,$address)
   {

 
$sql1="SELECT * FROM register WHERE phone='$phone' OR email='$email'";

global $con;
$result=mysqli_query($con,$sql1);
 if(mysqli_num_rows($result) != 0)
   {   global $response;
	   $response['error']=false;
     $response['message']="existed";

   }

else
{

  $sql="INSERT INTO register (name,password,email,user_type,phone,address) VALUES('$username','$password','$email','$user_type','$phone','$address')";
  
  global $con;
 if(mysqli_query($con,$sql)) 
 {  global $response;
	 $response['error']=false;
	 $response['message']="Registered successfully";
 }
   }
  }
 $response=array();
 
   if($_SERVER['REQUEST_METHOD']=='POST')
   {
	   if(empty($_POST['username']) or empty($_POST['password']) or empty($_POST['email']) or empty($_POST['user_type']) or empty($_POST['phone']) or empty($_POST['address']) )
	   {
		   $response['error']=true;
		   $response['message']="Enter all the fields";
		   
			
	   }
	
	   else
	  { if(isset($_POST['username']))
		{
		   if(isset($_POST['password']))
			   if(isset($_POST['email']))
			    {
				if(isset($_POST['user_type']))
			    {
				if(isset($_POST['phone']))
			    {
				if(isset($_POST['address']))
			    {
				    $username = mysqli_real_escape_string($con, $_POST['username']);
					$password = mysqli_real_escape_string($con, $_POST['password']);
					$email = mysqli_real_escape_string($con, $_POST['email']);
					$user_type = mysqli_real_escape_string($con, $_POST['user_type']);
					$phone = mysqli_real_escape_string($con, $_POST['phone']);
					$address = mysqli_real_escape_string($con, $_POST['address']);
					createUser($username,$password,$email,$user_type,$phone,$address);
					}
					}
		          }
				}	
		}
	  }  
   }
   else{
	  $response['error']=true;
	   $response['message']="invalid request";
   }
echo json_encode($response);
   
   ?>
   