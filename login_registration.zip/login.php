<?php

$response = array();



if($_SERVER['REQUEST_METHOD']=='POST'){

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
} 


	$name = $_POST['name'];
   $password = $_POST['password'];
   $user_type = $_POST['user_type'];
   

$sql="SELECT * FROM register WHERE name = '$name' AND password='$password'";

  
$result = $conn->query($sql);


if ($result->num_rows > 0) 
{

   $response["products"] = array();

   while($row = $result->fetch_assoc()) {
     
       $product = array();
       $product["id"] = $row["id"]; 
       $product["name"] = $row["name"];
       $product["password"] = $row["password"];
       $product["email"] = $row["email"];
        $product["user_type"] = $row["user_type"];
		 $product["address"] = $row["address"];
		  $product["phone"] = $row["phone"];
       array_push($response["products"], $product);
   }

   $response["success"] = 1;

   echo json_encode($response);
} else {
  
   $response["success"] = 0;
   $response["message"] = "No person found";

   echo json_encode($response);
}
}
?>